#include <stdio.h>
int main(){

  //practice
  int price = 500, qty=25, paid=180000, total= qty*price, change=paid-total, bonusCandy =change/1000, remaning=change%1000;
  printf("\t---------------------------------------------------------------------\n");
  printf("|Price|\t|Qty|\t|Total|\t\t|Paid|\t\t|Change|\t|Bonus Candy|\t|Remaining|\n");
  printf("\t---------------------------------------------------------------------\n");
  printf("%d\t%d\t%d riels\t%d riels\t%d riels\t%d pcs\t\t%d riels\n",price,qty,total,paid,change,bonusCandy,remaning);
  printf("\t---------------------------------------------------------------------\n");
  
  /*Lab: Chapter 5- Operators (Arithmetic Operators)*/
  //1
  double balance=100, deposit=50, newbalance= balance+deposit;
  printf("\nEnter Balance:\t%.lf",balance);
  printf("\nEnter Deposit:\t%.lf",deposit);
  printf("\nNew balance  :\t%.2lf$",newbalance);
  //2
  double balance2=200, withdraw2=33.5, newbalance2= balance2-withdraw2;
  printf("\n\t---------------------------------------------------------------------\n");
  printf("\n\nEnter Balance:\t%.2lf",balance2);
  printf("\nEnter Deposit:\t%.2lf",withdraw2);
  printf("\nNew balance  :\t%.2lf$\n\n",newbalance2);
  
  //3
  double balance3=1000,rate=6,interest=(balance3*rate)/100, newbalance3=balance3+interest,yearlyinterest=interest*12;
  char percent='s';
  //let says the interest rate is 6% monthly, therefore yearly interest rate = rate*12month
  printf("\t---------------------------------------------------------------------\n");
  printf("Enter Balance\t:\t$%0.f",balance3);
  printf("\nEnter rate(%c)\t:\t$%.f",percent,rate);
  printf("\nNew balance\t: \t$%.2f",newbalance2);
  printf("\nInterest\t: \t$%.2f",interest);
  printf("\nNew Balance\t: \t$%.2f",newbalance3);
  printf("\nYearly Interest\t: \t$%.2f",yearlyinterest);
  printf("\n\t---------------------------------------------------------------------\n");

  return 0;
}